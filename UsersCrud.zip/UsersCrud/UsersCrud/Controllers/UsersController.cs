﻿using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using usersCrud.DataAccess;
using usersCrud.Models;

namespace usersCrud.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly OracleDbContext _context;

        public UsersController(OracleDbContext context)
        {
            _context = context;
        }


        [HttpGet("getall")]
        public async Task<IActionResult> GetAllEmployees()
        {
            List<Employee> employees = new List<Employee>();

            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using (var command = new OracleCommand("gk_pkg_employee.get_all_employees", (OracleConnection)connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("o_users", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            var employee = new Employee
                            {
                                employee_id = reader.IsDBNull(reader.GetOrdinal("employee_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("employee_id")),
                                first_name = reader.IsDBNull(reader.GetOrdinal("first_name")) ? null : reader.GetString(reader.GetOrdinal("first_name")),
                                last_name = reader.IsDBNull(reader.GetOrdinal("last_name")) ? null : reader.GetString(reader.GetOrdinal("last_name")),
                                person_id = reader.IsDBNull(reader.GetOrdinal("person_id")) ? null : reader.GetString(reader.GetOrdinal("person_id")),
                                age = reader.IsDBNull(reader.GetOrdinal("age")) ? 0 : reader.GetInt32(reader.GetOrdinal("age")),
                                profession_id = reader.IsDBNull(reader.GetOrdinal("profession_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("profession_id"))
                            };

                            employees.Add(employee);
                        }
                    }
                }
            }

            return Ok(employees);
        }

        [HttpGet("professions")]
        public async Task<IActionResult> GetProfessions()
        {
            List<Profession> professions = new List<Profession>();

            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using (var command = new OracleCommand("gk_pkg_employee.get_all_professions", (OracleConnection)connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Setup the output parameter
                    OracleParameter outParameter = command.Parameters.Add("o_professions", OracleDbType.RefCursor);
                    outParameter.Direction = ParameterDirection.Output;

                    // Execute the command
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (reader.Read())
                        {
                            var profession = new Profession
                            {
                                profession_id = reader.GetInt32(reader.GetOrdinal("profession_id")),
                                profession_name = reader.GetString(reader.GetOrdinal("profession_name"))
                            };

                            professions.Add(profession);
                        }
                    }
                }
            }

            return Ok(professions);
        }


        [HttpPost("create")]
        public async Task<IActionResult> CreateEmployee(Employee employee)
        {
            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using (var command = new OracleCommand("gk_pkg_employee.create_employee", (OracleConnection)connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Add input parameters
                    command.Parameters.Add("p_first_name", OracleDbType.Varchar2).Value = employee.first_name;
                    command.Parameters.Add("p_last_name", OracleDbType.Varchar2).Value = employee.last_name;
                    command.Parameters.Add("p_person_id", OracleDbType.Varchar2).Value = employee.person_id;
                    command.Parameters.Add("p_age", OracleDbType.Int32).Value = employee.age;
                    command.Parameters.Add("p_profession_id", OracleDbType.Int32).Value = employee.profession_id;

                    // Execute the command
                    await command.ExecuteNonQueryAsync();
                }
            }

            return Ok("Employee created successfully");
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetEmployeeById(int id)
        {
            Employee employee = null;

            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using (var command = new OracleCommand("gk_pkg_employee.get_employee", (OracleConnection)connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("p_id", OracleDbType.Int32).Value = id;
                    command.Parameters.Add("o_employee", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.Read())
                        {
                            employee = new Employee
                            {
                                employee_id = reader.IsDBNull(reader.GetOrdinal("employee_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("employee_id")),
                                first_name = reader.IsDBNull(reader.GetOrdinal("first_name")) ? null : reader.GetString(reader.GetOrdinal("first_name")),
                                last_name = reader.IsDBNull(reader.GetOrdinal("last_name")) ? null : reader.GetString(reader.GetOrdinal("last_name")),
                                person_id = reader.IsDBNull(reader.GetOrdinal("person_id")) ? null : reader.GetString(reader.GetOrdinal("person_id")),
                                age = reader.IsDBNull(reader.GetOrdinal("age")) ? 0 : reader.GetInt32(reader.GetOrdinal("age")),
                                profession_id = reader.IsDBNull(reader.GetOrdinal("profession_id")) ? 0 : reader.GetInt32(reader.GetOrdinal("profession_id"))
                            };
                        }
                    }
                }
            }

            if (employee == null)
            {
                return NotFound(); // Return 404
            }

            return Ok(employee); // Return
        }



        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEmployee(int id, Employee updatedEmployee)
        {
            try
            {
                using (var connection = _context.CreateConnection())
                {
                    connection.Open();
                    using (var command = new OracleCommand("gk_pkg_employee.update_employee", (OracleConnection)connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add("p_id", OracleDbType.Int32).Value = id;
                        command.Parameters.Add("p_first_name", OracleDbType.Varchar2).Value = updatedEmployee.first_name;
                        command.Parameters.Add("p_last_name", OracleDbType.Varchar2).Value = updatedEmployee.last_name;
                        command.Parameters.Add("p_person_id", OracleDbType.Varchar2).Value = updatedEmployee.person_id;
                        command.Parameters.Add("p_age", OracleDbType.Int32).Value = updatedEmployee.age;
                        command.Parameters.Add("p_profession_id", OracleDbType.Int32).Value = updatedEmployee.profession_id;

                        await command.ExecuteNonQueryAsync();
                    }
                }

                // Return a JSON response with the updated employee data
                var updatedData = new { message = "Employee updated successfully.", employee = updatedEmployee };
                return Ok(updatedData);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while updating employee: {ex.Message}"); // Return a custom error message
            }
        }




        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEmployee(int id)
        {
            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using (var command = new OracleCommand("gk_pkg_employee.delete_employee", (OracleConnection)connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("p_id", OracleDbType.Int32).Value = id;

                    await command.ExecuteNonQueryAsync();
                }
            }

            return Ok("Employee deleted successfully.");
        }


    }
}
