﻿namespace usersCrud.Models
{
    public class Employee
    {
        public int? employee_id { get; set; }
        public string first_name{get; set;}
        public string last_name { get; set;}
        public string person_id { get; set;}
        public int age { get; set;}
        public int profession_id { get; set; }
    }
}
