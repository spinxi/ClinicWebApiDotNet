﻿namespace usersCrud.Models
{
    public class Profession
    {
        public int profession_id { get; set; }
        public string profession_name { get; set; }
    }
}
